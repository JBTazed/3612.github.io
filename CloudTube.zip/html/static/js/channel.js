import {q} from "/static/js/elemjs/elemjs.js"
import {SubscribeButton} from "/static/js/modules/SubscribeButton.js"

new SubscribeButton(q("#subscribe"))